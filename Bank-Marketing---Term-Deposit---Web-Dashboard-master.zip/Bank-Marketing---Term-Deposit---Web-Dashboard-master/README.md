# Bank-Marketing---Term-Deposit---Web-Dashboard

![Analytics Dashboard](https://www.elegantthemes.com/blog/wp-content/uploads/2016/02/google-analytics-custom-dashboard.jpg)

** To run, **

*pip install -r requirements.txt*

*python manage.py runserver*

## Some Screenshots:

### Screenshot-1
![screenshot-1](https://user-images.githubusercontent.com/18166377/66329114-9863b100-e94b-11e9-926d-b953addcb4de.png)

### Screenshot-2
![Screenshot-2](https://user-images.githubusercontent.com/18166377/66329225-c9dc7c80-e94b-11e9-94b3-91b5565d32a7.png)

### Screenshot-3
![Screenshot-3](https://user-images.githubusercontent.com/18166377/66397501-96582b80-e9f9-11e9-8889-ec1aa9ef528c.png)

### Screenshot-4
![Screenshot-4](https://user-images.githubusercontent.com/18166377/66329327-f85a5780-e94b-11e9-9ed7-36b54d2f7554.png)

### Page-1
![Page1](https://user-images.githubusercontent.com/18166377/66398851-25664300-e9fc-11e9-8af2-31ac4e3375d9.png)
