from django.apps import AppConfig


class DataVisualizationConfig(AppConfig):
    name = 'data_visualization'
