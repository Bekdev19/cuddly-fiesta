
dataset_path = 'data/bank.csv'
